<?php

    include 'testing.php';

    if(isset($_POST['option'])){
        if($_POST['option'] == "create"){
            
            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $nim = $_POST['nim'];
            $program_studi = $_POST['program_studi'];
            
            $query = "INSERT INTO mahasiswa VALUES('$id', '$nama','$nim','$program_studi')";
            $sql = mysqli_query($test, $query);

            if($sql){
               header("Location: index.php");
            } else {
                echo $query;
            }

            // echo "Create Data 
            //      <a href='index.php'>[Home]</a>";
        }else if($_POST["option"] == "edit"){

            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $nim = $_POST['nim'];
            $program_studi = $_POST['program_studi'];

            $query = "UPDATE mahasiswa SET nama='$nama', nim='$nim', program_studi='$program_studi' WHERE id='$id';";

            $sql = mysqli_query($test, $query);
            if($sql){
                header("Location: index.php");
             } else {
                 echo $query;
             }
        }        
    }
    if(isset($_GET['delete'])){
        $id = $_GET['delete'];

        $query = "DELETE FROM mahasiswa WHERE id = '$id';";
        $sql = mysqli_query($test, $query);
        if($sql){
            header("Location: index.php");
         } else {
             echo $query;
         }
    }

?>




