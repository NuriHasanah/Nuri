<!DOCTYPE html>
<?php 
include 'testing.php';

              $id = '';
              $nama = '';
              $nim = '';
              $program_studi = '';

          if(isset($_GET['change'])) {
              $id = $_GET['change'];

              $query = "SELECT * FROM mahasiswa WHERE id = '$id'";
              $sql = mysqli_query($test, $query);

              $result = mysqli_fetch_assoc($sql);

              $nama = $result['nama'];
              $nim = $result['nim'];
              $program_studi = $result['program_studi'];

          }
        ?>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
  </head>
  <body>
  <section class="section">
    <form method="POST" action="progres.php">
      <input type="hidden" value="<?php echo $id;?>" name="id">
    <div class="container">
      <h1 class="title">
        Buat Data Mahasiswa Baru
      </h1>
      <p class="subtitle">
        Tahun Ajaran Genap 2022/2023 <strong></strong>
      </p>
      <div class="field">
        <label class="label">Nama</label>
        <div class="control">
          <input name="nama" id="nama" class="input" type="text" placeholder="Masukkan Nama" value ="<?php echo $nama;?>">
        </div>
      </div>
      <div class="field">
        <label class="label">NIM</label>
        <div class="control">
          <input name="nim" id="nim" class="input" type="text" placeholder="Masukkan NIM" value ="<?php echo $nim;?>">
        </div>
      </div>
      
      <div class="field">
        <label class="label">Program Studi</label>
        <div class="control">
          <input name="program_studi" id="program_studi" class="input" type="text" placeholder="Masukkan Program Studi" value ="<?php echo $program_studi;?>">
        </div>
      </div>

      <div class="buttons">
        <?php 
          if(isset($_GET['change'])) {
        ?>
        <button type="submit" name="option" value="edit" class="button is-success">Save Changes</button>
            <?php
              } else {
            ?>
         <button type="submit" name="option" value="create"class="button is-success">Create Data</button>
         <?php
              }
            ?>
        <a href="index.php" class="button is-danger">Cancel</a>
      </div>
    </div>
    </form>
  </section>
  </body>
</html>