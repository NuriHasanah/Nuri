<?php
    $host = 'localhost';
    $username = 'root';
    $password = ' ';
    $database = 'siakad';


    $test = mysqli_connect($host, $username, $password, $database);
    if(!$test) {
      echo "Database isn't Connected";
    }

    mysqli_select_db($test, $database);
?>

