<?php

    include 'testing.php';

    if(isset($_POST['option'])){
        if($_POST['option'] == "create"){
            
            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $nidn = $_POST['nidn'];
            $jenjang_pendidikan = $_POST['jenjang_pendidikan'];
            
            $query = "INSERT INTO dosen VALUES('$id', '$nama','$nidn','$jenjang_pendidikan')";
            $sql = mysqli_query($test, $query);

            if($sql){
               header("Location: index.php");
            } else {
                echo $query;
            }

            
        }else if($_POST["option"] == "edit"){

            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $nidn = $_POST['nidn'];
            $jenjang_pendidikan = $_POST['jenjang_pendidikan'];

            $query = "UPDATE dosen SET nama='$nama', nidn='$nidn', jenjang_pendidikan='$jenjang_pendidikan' WHERE id='$id';";

            $sql = mysqli_query($test, $query);
            if($sql){
                header("Location: index.php");
             } else {
                 echo $query;
             }
        }        
    }
    if(isset($_GET['delete'])){
        $id = $_GET['delete'];

        $query = "DELETE FROM dosen WHERE id = '$id';";
        $sql = mysqli_query($test, $query);
        if($sql){
            header("Location: index.php");
         } else {
             echo $query;
         }
    }

?>




