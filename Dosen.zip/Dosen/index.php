<?php 
  include 'testing.php';
  
  $query = "SELECT * FROM dosen";
  $sql = mysqli_query($test, $query);
  $no = 0;

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UTS CRUD</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
  </head>
  <body>
  <section class="section">
    <div class="container">
      <h1 class="title">
        Data Dosen
      </h1>
      <p class="subtitle">
        Tahun Ajaran Genap 2022/2023 <strong></strong>
      </p>
      
      <table class="table is-fullwidth">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>NIDN</th>
            <th>Jenjang Pendidikan</th>
            <th>Option</th>
          </tr>
        </thead>
        <tbody>
        <?php
              while($result = mysqli_fetch_assoc($sql)) {
          ?>
            <tr>
                <td><?php echo ++$no;?>.</td>
                <td><?php echo $result['nama'];?></td>
                <td><?php echo $result['nidn'];?></td>
                <td><?php echo $result['jenjang_pendidikan'];?></td>
                <td>
                    <a href="administrator.php?change=<?php echo $result['id'];?>" class="button is-link button is-small">Edit</a>
                    <a href="progres.php?delete=<?php echo $result['id'];?>" class="button is-danger button is-small">Delete</a>
                </td>
            </tr>
          <?php
              }
          ?>
        </tbody>
       </table>
       <a href="administrator.php" class="button is-info">Create</a>
    </div>
  </section>
  </body>
</html>