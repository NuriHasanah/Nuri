<?php

    include 'testing.php';

    if(isset($_POST['option'])){
        if($_POST['option'] == "create"){
            
            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $kode_matakul = $_POST['kode_matakul'];
            $deskripsi = $_POST['deskripsi'];
            
            $query = "INSERT INTO mata_kuliah VALUES('$id', '$nama','$kode_matakul','$deskripsi')";
            $sql = mysqli_query($test, $query);

            if($sql){
               header("Location: index.php");
            } else {
                echo $query;
            }

        }else if($_POST["option"] == "edit"){

            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $kode_matakul = $_POST['kode_matakul'];
            $deskripsi = $_POST['deskripsi'];

            $query = "UPDATE mata_kuliah SET nama='$nama', kode_matakul='$kode_matakul', deskripsi='$deskripsi' WHERE id='$id';";

            $sql = mysqli_query($test, $query);
            if($sql){
                header("Location: index.php");
             } else {
                 echo $query;
             }
        }        
    }
    if(isset($_GET['delete'])){
        $id = $_GET['delete'];

        $query = "DELETE FROM mata_kuliah WHERE id = '$id';";
        $sql = mysqli_query($test, $query);
        if($sql){
            header("Location: index.php");
         } else {
             echo $query;
         }
    }

?>




