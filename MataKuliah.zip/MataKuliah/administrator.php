<!DOCTYPE html>
<?php 
include 'testing.php';

              $id = '';
              $nama = '';
              $kode_matakul = '';
              $deskripsi = '';

          if(isset($_GET['change'])) {
              $id = $_GET['change'];

              $query = "SELECT * FROM mata_kuliah WHERE id = '$id'";
              $sql = mysqli_query($test, $query);

              $result = mysqli_fetch_assoc($sql);

              $nama = $result['nama'];
              $kode_matakul = $result['kode_matakul'];
              $deskripsi = $result['deskripsi'];

          }
        ?>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
  </head>
  <body>
  <section class="section">
    <form method="POST" action="progres.php">
      <input type="hidden" value="<?php echo $id;?>" name="id">
    <div class="container">
      <h1 class="title">
        Buat Data Mata Kuliah Baru
      </h1>
      <p class="subtitle">
        Tahun Ajaran Genap 2022/2023 <strong></strong>
      </p>
      <div class="field">
        <label class="label">Nama</label>
        <div class="control">
          <input name="nama" id="nama" class="input" type="text" placeholder="Masukkan Nama" value ="<?php echo $nama;?>">
        </div>
      </div>
      <div class="field">
        <label class="label">Kode Mata Kuliah</label>
        <div class="control">
          <input name="kode_matakul" id="kode_matakul" class="input" type="text" placeholder="Masukkan Kode" value ="<?php echo $kode_matakul;?>">
        </div>
      </div>
      
      <div class="field">
        <label class="label">Deskripsi</label>
        <div class="control">
          <input name="deskripsi" id="deskri[si" class="input" type="text" placeholder="Masukkan Deskripsi" value ="<?php echo $deskripsi;?>">
        </div>
      </div>

      <div class="buttons">
        <?php 
          if(isset($_GET['change'])) {
        ?>
        <button type="submit" name="option" value="edit" class="button is-success">Save Changes</button>
            <?php
              } else {
            ?>
         <button type="submit" name="option" value="create"class="button is-success">Create Data</button>
         <?php
              }
            ?>
        <a href="index.php" class="button is-danger">Cancel</a>
      </div>
    </div>
    </form>
  </section>
  </body>
</html>